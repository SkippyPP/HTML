name = input("Please enter your name: ")
adjOne = input("Please enter an adjective: ")
place = input("Please enter in a place: ")
storyOne = "Hello " + name + ", today you start your " + adjOne + " journey to " + place + ". "
print(storyOne)
emotion = input("Please pick an emotion: ")
while 1:
    try:
        num = int(input("Please enter in a whole number between 0-12: "))
        while num < 0 or num>12:
            print("This number is outside of the range")
            num = int(input("Please enter in a whole number between 0-12: ")) 
                   
        if num == 0:
            print("got here")
            storyTwo= "As soon as you start your adventure, you find yourself very " + emotion + "."
            print(storyTwo)
        else:
            storyTwoAlt = "After walking for " + str(num) + " hours, you feel very " + emotion + ". "
            print(storyTwoAlt)
        break
    except:
        print("We asked for a whole number")

adjTwo = input("Please enter an adjective: ")
animal = input("Please enter an animal: ")
storyThree = "After another 30 minutes of walking, you encounter a/an " + adjTwo + " " + animal + ". "
print(storyThree)
fruit = input("Please pick a fruit: ")
storyFour = "Luckily, you brought a comically large " + fruit + " and subdue it. "
print(storyFour)
storyFive = animal + " refers to you as master now and offers you a ride to your destination. "
print(storyFive)
emotionTwo = input("Please pick an emotion: ")
storySix = "You feel very " + emotionTwo + " but accept the free ride nonetheless. On the way to " + place + ", you find a water puddle. Due to being very parched, you consider drinking it."
print(storySix)
choice = input("Please choose between yes or no: ")
if choice=="yes" or choice =="Yes":
    print("You become all wheezy and pass out, the water gave you amnesia and you can't remember who you are. When you wake up, you find yourself as the tribe leader of the " + animal)
else:
    action = input("Please choose an action")
    print("You almost died due to thirst, but the " + animal + " gave you their last limited edition Coca Cola from the marvel collaboration. You made to your destination so you finally could " + action)