﻿namespace PigLatin
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtMain = new TextBox();
            btnPigToEnglish = new Button();
            txtPigLatin = new TextBox();
            label1 = new Label();
            label2 = new Label();
            btnEngToPig = new Button();
            SuspendLayout();
            // 
            // txtMain
            // 
            txtMain.Location = new Point(41, 29);
            txtMain.Name = "txtMain";
            txtMain.Size = new Size(238, 23);
            txtMain.TabIndex = 0;
            // 
            // btnPigToEnglish
            // 
            btnPigToEnglish.Location = new Point(41, 58);
            btnPigToEnglish.Name = "btnPigToEnglish";
            btnPigToEnglish.Size = new Size(84, 55);
            btnPigToEnglish.TabIndex = 1;
            btnPigToEnglish.Text = "Convert \r\nTo English";
            btnPigToEnglish.UseVisualStyleBackColor = true;
            btnPigToEnglish.Click += btnConvert_Click;
            // 
            // txtPigLatin
            // 
            txtPigLatin.Location = new Point(21, 119);
            txtPigLatin.Name = "txtPigLatin";
            txtPigLatin.ReadOnly = true;
            txtPigLatin.Size = new Size(284, 23);
            txtPigLatin.TabIndex = 2;
            txtPigLatin.Visible = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(91, 38);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(55, 11);
            label2.Name = "label2";
            label2.Size = new Size(215, 15);
            label2.TabIndex = 4;
            label2.Text = "Enter a word with more than 1 charcter ";
            // 
            // btnEngToPig
            // 
            btnEngToPig.Location = new Point(186, 58);
            btnEngToPig.Name = "btnEngToPig";
            btnEngToPig.Size = new Size(84, 55);
            btnEngToPig.TabIndex = 5;
            btnEngToPig.Text = "Convert\r\nTo PigLatin";
            btnEngToPig.UseVisualStyleBackColor = true;
            btnEngToPig.Click += btnPigToEng_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(326, 168);
            Controls.Add(btnEngToPig);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtPigLatin);
            Controls.Add(btnPigToEnglish);
            Controls.Add(txtMain);
            Name = "Form1";
            Text = "Main Form";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtMain;
        private Button btnPigToEnglish;
        private TextBox txtPigLatin;
        private Label label1;
        private Label label2;
        private Button btnEngToPig;
    }
}
