using System.Runtime.CompilerServices;

namespace PigLatin
{
    public partial class Form1 : Form
    {
        string PIG_LATIN_ENDING = "ay";
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e) // This code will convert Pig Latin into English
        {   
            //Checking if they input something other than a string
            bool isFormValueDouble = double.TryParse(txtMain.Text, out double validDoubleValue); 
            bool isFormValueInt = int.TryParse(txtMain.Text, out int validIntValue);

            if (txtMain.Text.Length <= 1)   //Checks if they input noting or just a letter
            {
                MessageBox.Show("Please enter a word longer than one chracter", "String Entry Incorrect", MessageBoxButtons.OK); //Shows an error message 
                txtMain.Focus();
                txtMain.SelectAll();
            }
            else
            {
                if (isFormValueDouble || isFormValueInt) //If the input is an Int or double, show an error
                {
                    MessageBox.Show("Please enter a valid Input", "String Entry Incorrect", MessageBoxButtons.OK);
                    txtMain.Focus();
                    txtMain.SelectAll();
                }
                else
                {
                   //This declares two variables for the starting letter of the word and the rest of the word
                        String MiddleLettters, Startingletter;
                        MiddleLettters = txtMain.Text.Substring(0, txtMain.Text.Length - 3);    //This gets the rest of the word
                        Startingletter = txtMain.Text.Substring(txtMain.Text.Length - 3, 1);    //This code gets the starting letter
                        txtPigLatin.Text = Startingletter + MiddleLettters; 
                    
          
                }
            }
        }

        private void btnPigToEng_Click(object sender, EventArgs e) //This Code will turn English into Pig Latin
        {
            bool isFormValueDouble = double.TryParse(txtMain.Text, out double validDoubleValue);
            bool isFormValueInt = int.TryParse(txtMain.Text, out int validIntValue);

            if (txtMain.Text.Length <= 1)
            {
                MessageBox.Show("Please enter a word longer than one chracter", "String Entry Incorrect", MessageBoxButtons.OK);
                txtMain.Focus();
                txtMain.SelectAll();
            }
            else
            {
                if (isFormValueDouble || isFormValueInt)
                {
                    MessageBox.Show("Please enter a valid Input", "String Entry Incorrect", MessageBoxButtons.OK);
                    txtMain.Focus();
                    txtMain.SelectAll();
                }
                else
                {
                    string firstLetter, restOfWord;
                    firstLetter = txtMain.Text.Substring(0, 1);
                    restOfWord = txtMain.Text.Substring(1, txtMain.Text.Length - 1);
                    txtPigLatin.Text = restOfWord + firstLetter + PIG_LATIN_ENDING; //This combines the rest of the word, the first letter, and "ay" 
                    if (!txtPigLatin.Visible) txtPigLatin.Visible = true;   //This turns the textbox that was invisiable before, visiable
                }
            }    }
    }
}
