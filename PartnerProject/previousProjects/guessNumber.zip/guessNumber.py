import random   #This line is needed to use the random number generator
randomNum = random.randint(1,99) #This prompts the program to generate a random number
guess = 0 #This will count the numbers of guesses the user makes
numOfGuess = 0
while guess != randomNum: #This creates a loop until the user gusses the number
    try:
        guess = int(input("Please enter your guess on the interger between 1-99 inclusive: "))
        numOfGuess+=1 #Will count the gusses 
        if guess<1 or guess>99: #makes sure number is in the range
            print("Your guess is outside the range, please try again.")
        elif guess>randomNum:
            print("Your guess is to high, please try again")
        elif guess<randomNum:
            print("Your guess is too low, please try again.")
        else:
            break
    except:
        print("Your guess is not an integer, please try again ")
print("Congratulations, You got the number in " + str(numOfGuess) + " guesses.")
    